module.exports = {
    env: {
      mnemonic:"deer palace nation sport pact sail second mandate share pear radio visit",
      accessToken : "https://rinkeby.infura.io/v3/24a73a24211e4c40b448462191ef9ee2",
      account: '0x6b618992885eDb0355A8c30A92D0F0E246388526',
      api:'user_unrv8F0p0XFdSIvWfq6GF'
    },
  }